import requests

def test():
    api_key = "AIzaSyCYhzjQdUOmnKuIY2jvgzy5WfF2yf3S2FI"
    url = f"https://generativelanguage.googleapis.com/v1beta/models?key={api_key}"
    r = requests.get(url)
    print(r.status_code)
    for model in r.json().get("models", []):
        print(model["name"])

test()
